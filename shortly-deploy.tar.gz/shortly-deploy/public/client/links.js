Shortly.Links = Backbone.Collection.extend({
  model: Shortly.Link,
  url: '/links'
});
