Shortly.Link = Backbone.Model.extend({
  urlRoot: '/links'
});
