#shortly-deploy
This is a project I completed as a student at [hackreactor](http://hackreactor.com). This project was worked on with a pair.